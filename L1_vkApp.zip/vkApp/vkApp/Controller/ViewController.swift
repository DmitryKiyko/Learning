//
//  ViewController.swift
//  vkApp
//
//  Created by Dmitry Kiyko on 30.03.2021.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!
    
    @IBOutlet weak var usernameTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBAction func buttonTapped(_ sender: Any) {
        if
            usernameTextfield.text == "admin",
            passwordTextfield.text == "qwerty" {
                print("Auth success")
        } else {
                print("Auth denied")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        usernameLabel.text = "MyUserName"
        passwordLabel.text = "Qwerty"
        loginButton.setTitle("Login", for: [])
    }
    
    
    
}

