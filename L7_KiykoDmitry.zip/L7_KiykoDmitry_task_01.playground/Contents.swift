import UIKit
import Foundation

// Ошибки обработки запросов
enum ATMErrors: Error {
    case InvalidCardType
    case IncorrectPinCode
    case InvalidCurrencyType
    case InsufficientFunds
}

// Параметры банковских карт
struct Features {
    var currency: String
    var pincode: Int
    var MoneyAmount: Decimal
}

// Задание № 1. Обработка опционального результата или ошибки

// Банкомат
class ATM {
    // Данные банковских карт
    var CardDataBase = [
        "VISA": Features(currency: "USD", pincode: 2591, MoneyAmount: 2534.16),
        "Maestro": Features(currency: "EURO", pincode: 8301, MoneyAmount: 3021.79),
        "Mastercard": Features(currency: "EURO", pincode: 5077, MoneyAmount: 1802.35),
        "MIR": Features(currency: "RUB", pincode: 3146, MoneyAmount: 80921.62)
    ]
    
    // Метод выдачи наличных с карты
    func CashWithdrawal(CardType Type: String, PinCode Pin: Int, CurrencyRequest CurrencyReq: String, CashRequest CashReq: Decimal) -> (Features: String?, Decimal?, ATMErrors?) {
        
        guard let Card = CardDataBase[Type] else {
            return (nil, nil, ATMErrors.InvalidCardType)
        }
        
        guard Pin == Card.pincode else {
            return (nil, nil, ATMErrors.IncorrectPinCode)
        }
        
        guard CurrencyReq == Card.currency else {
            return (nil, nil, ATMErrors.InvalidCurrencyType)
        }
        
        guard CashReq <= Card.MoneyAmount else {
            return (nil, nil, ATMErrors.InsufficientFunds)
        }
        
        
        var CardUpdate = Card
        CardUpdate.MoneyAmount -= CashReq
        
        CardDataBase[Type] = CardUpdate
        
        print("Операция: \nВыдача наличных: \(CashReq)  \(CardUpdate.currency). Остаток на счете: \(CardUpdate.MoneyAmount)  \(CardUpdate.currency)")
        
        return (CardUpdate.currency, CardUpdate.MoneyAmount, nil)
    }
    
    
    // Метод внесения наличных на карту
    func CashDeposit(CardType Type: String, PinCode Pin: Int, CurrencyRequest CurrencyReq: String, CashRequest CashReq: Decimal) -> (Features: String?, Decimal?, ATMErrors?) {
        
        guard let Card = CardDataBase[Type] else {
            return (nil, nil, ATMErrors.InvalidCardType)
        }
        
        guard Pin == Card.pincode else {
            return (nil, nil, ATMErrors.IncorrectPinCode)
        }
        
        guard CurrencyReq == Card.currency else {
            return (nil, nil, ATMErrors.InvalidCurrencyType)
        }
        
        
        var CardUpdate = Card
        CardUpdate.MoneyAmount += CashReq
        
        CardDataBase[Type] = CardUpdate
        
        print("Операция: \nВнесение наличных: \(CashReq)  \(CardUpdate.currency). Остаток на счете: \(CardUpdate.MoneyAmount)  \(CardUpdate.currency)")
        
        return (CardUpdate.currency, CardUpdate.MoneyAmount, nil)
    }
    
}

let CashRequest: Decimal = 1500.0     // Сумма выдачи наличных
let CashDeposit: Decimal = 2100.0     // Сумма внесения наличных
let CardTypeW: String = "VISA"        // Тип карты для выдачи наличных
let CardTypeD: String = "MIR"        // Тип карты для внесения наличных
let PinCodeW: Int = 2591              // Пин код карты для выдачи наличных
let PinCodeD: Int = 3146              // Пин код карты для внесения наличных
let CurReqW: String = "USD"           // Валюта выдачи наличных
let CurReqD: String = "RUB"           // Валюта внесения наличных

var ATMCash = ATM()


// Вызов метода запроса выдачи наличных с обработкой ошибок

    let ATMCashW = ATMCash.CashWithdrawal(CardType: CardTypeW, PinCode: PinCodeW, CurrencyRequest: CurReqW, CashRequest: CashRequest)

if let _ = ATMCashW.0 {
    print("Операция успешна \n")
} else if let error = ATMCashW.2 {
    print("Операция не успешна. \nОшибка: \(error.localizedDescription), \(error) \n")
}


// Вызов метода запроса внесения наличных с обработкой ошибок

 let ATMCashD = ATMCash.CashDeposit(CardType: CardTypeD, PinCode: PinCodeD, CurrencyRequest: CurReqD, CashRequest: CashDeposit)

if let _ = ATMCashD.0 {
 print("Операция успешна \n")
} else if let error = ATMCashD.2 {
 print("Операция не успешна. \nОшибка: \(error.localizedDescription), \(error) \n")
}

