//
//  SomePage.swift
//  vkApp
//
//  Created by Dmitry Kiyko on 03.04.2021.
//

import UIKit

class SomePage: UIViewController {

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isHidden = false
    }

}
